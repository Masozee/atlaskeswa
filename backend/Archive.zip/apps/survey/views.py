from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Count, Q, Avg
from django.utils import timezone

from .models import (
    Survey, SurveyAttachment, SurveyAuditLog,
    GeographicUnit, SurveyTemplate, QuestionSection, Question,
    QuestionChoice, DynamicSurveyResponse, QuestionAnswer
)
from .serializers import (
    SurveyListSerializer, SurveyDetailSerializer,
    SurveyCreateUpdateSerializer, SurveySubmitSerializer,
    SurveyVerifySerializer, SurveyAttachmentSerializer,
    SurveyAuditLogSerializer,
    # Dynamic questionnaire serializers
    GeographicUnitSerializer,
    SurveyTemplateListSerializer, SurveyTemplateDetailSerializer,
    QuestionSerializer, QuestionCreateUpdateSerializer,
    QuestionChoiceSerializer, QuestionChoiceCreateUpdateSerializer,
    DynamicSurveyResponseListSerializer, DynamicSurveyResponseDetailSerializer,
    DynamicSurveyResponseCreateSerializer
)
from apps.accounts.permissions import (
    IsSurveyorOrAdmin, IsVerifierOrAdmin, IsSurveyOwnerOrReadOnly,
    CanModifySurveyStatus
)
from apps.accounts.mixins import SurveyorFilterMixin
from apps.logs.utils import (
    log_create, log_update, log_delete,
    log_survey_submit, log_survey_verify, log_survey_reject,
    log_file_upload
)


class SurveyViewSet(SurveyorFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for Survey with verification workflow
    """
    queryset = Survey.objects.select_related(
        'service', 'surveyor', 'assigned_verifier', 'verified_by'
    )
    permission_classes = [IsAuthenticated, IsSurveyOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]

    filterset_fields = {
        'service': ['exact'],
        'surveyor': ['exact'],
        'verification_status': ['exact'],
        'assigned_verifier': ['exact'],
        'survey_date': ['exact', 'gte', 'lte'],
        'created_at': ['gte', 'lte'],
    }

    search_fields = [
        'service__name', 'surveyor__email', 'surveyor_notes',
        'verifier_notes', 'challenges_faced'
    ]

    ordering_fields = ['survey_date', 'created_at', 'verification_status']
    ordering = ['-survey_date']

    def get_serializer_class(self):
        if self.action == 'list':
            return SurveyListSerializer
        elif self.action in ['create', 'update', 'partial_update']:
            return SurveyCreateUpdateSerializer
        elif self.action == 'submit':
            return SurveySubmitSerializer
        elif self.action == 'verify':
            return SurveyVerifySerializer
        return SurveyDetailSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update']:
            return [IsSurveyorOrAdmin(), IsSurveyOwnerOrReadOnly()]
        elif self.action == 'verify':
            return [IsVerifierOrAdmin(), CanModifySurveyStatus()]
        elif self.action == 'submit':
            return [IsSurveyorOrAdmin(), CanModifySurveyStatus()]
        return [IsAuthenticated(), IsSurveyOwnerOrReadOnly()]

    # RBAC Mixin Configuration
    rbac_surveyor_field = 'surveyor'
    rbac_verifier_field = 'assigned_verifier'
    rbac_status_field = 'verification_status'
    rbac_verified_status = 'VERIFIED'
    rbac_submitted_status = 'SUBMITTED'
    rbac_admin_sees_all = True
    rbac_allow_superuser = True

    # get_queryset is now handled by SurveyorFilterMixin
    # The mixin automatically filters based on role:
    # - ADMIN: sees all surveys
    # - SURVEYOR: sees own surveys (surveyor=user)
    # - VERIFIER: sees assigned + submitted surveys
    # - VIEWER: sees only verified surveys

    def perform_create(self, serializer):
        """Set surveyor to current user and log activity"""
        instance = serializer.save(surveyor=self.request.user)
        log_create(self.request, instance, f'Created survey for service: {instance.service.name}')

    def perform_update(self, serializer):
        """Update survey and log activity"""
        instance = serializer.save()
        log_update(self.request, instance, f'Updated survey for service: {instance.service.name}')

    def perform_destroy(self, instance):
        """Delete survey and log activity"""
        log_delete(self.request, instance, f'Deleted survey for service: {instance.service.name}')
        instance.delete()

    @action(detail=True, methods=['post'])
    def submit(self, request, pk=None):
        """Submit survey for verification"""
        survey = self.get_object()

        # Check if survey can be submitted
        if survey.verification_status != Survey.Status.DRAFT:
            return Response(
                {'detail': 'Only draft surveys can be submitted'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Check if user is the surveyor
        if survey.surveyor != request.user and request.user.role != 'ADMIN':
            return Response(
                {'detail': 'Only the surveyor can submit this survey'},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = SurveySubmitSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Update survey
        survey.verification_status = Survey.Status.SUBMITTED
        survey.submitted_at = timezone.now()

        # Assign verifier if provided
        if 'assigned_verifier' in serializer.validated_data:
            survey.assigned_verifier = serializer.validated_data['assigned_verifier']

        survey.save()

        # Create audit log
        SurveyAuditLog.objects.create(
            survey=survey,
            action=SurveyAuditLog.Action.SUBMITTED,
            user=request.user,
            previous_status=Survey.Status.DRAFT,
            new_status=Survey.Status.SUBMITTED,
            notes='Survey submitted for verification'
        )

        # Log activity
        log_survey_submit(request, survey)

        return Response(SurveyDetailSerializer(survey).data)

    @action(detail=True, methods=['post'])
    def verify(self, request, pk=None):
        """Verify or reject survey"""
        survey = self.get_object()

        # Check if survey can be verified
        if survey.verification_status != Survey.Status.SUBMITTED:
            return Response(
                {'detail': 'Only submitted surveys can be verified'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Strict separation of duties: cannot verify your own submission
        if survey.surveyor == request.user:
            return Response(
                {'detail': 'You cannot verify your own survey submission'},
                status=status.HTTP_403_FORBIDDEN
            )

        # Check if user has permission to verify (VERIFIER or ADMIN)
        if request.user.role not in ['VERIFIER', 'ADMIN']:
            return Response(
                {'detail': 'Only verifiers and admins can verify surveys'},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer = SurveyVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        action_type = serializer.validated_data['action']
        notes = serializer.validated_data.get('notes', '')

        previous_status = survey.verification_status

        if action_type == 'verify':
            survey.verification_status = Survey.Status.VERIFIED
            survey.verified_by = request.user
            survey.verified_at = timezone.now()
            survey.verifier_notes = notes
            audit_action = SurveyAuditLog.Action.VERIFIED
        else:  # reject
            survey.verification_status = Survey.Status.REJECTED
            survey.rejection_reason = serializer.validated_data.get('rejection_reason', '')
            survey.verifier_notes = notes
            audit_action = SurveyAuditLog.Action.REJECTED

        survey.save()

        # Create audit log
        SurveyAuditLog.objects.create(
            survey=survey,
            action=audit_action,
            user=request.user,
            previous_status=previous_status,
            new_status=survey.verification_status,
            notes=notes
        )

        # Log activity
        if action_type == 'verify':
            log_survey_verify(request, survey)
        else:
            log_survey_reject(request, survey, serializer.validated_data.get('rejection_reason', ''))

        return Response(SurveyDetailSerializer(survey).data)

    @action(detail=True, methods=['get'])
    def attachments(self, request, pk=None):
        """Get all attachments for this survey"""
        survey = self.get_object()
        attachments = SurveyAttachment.objects.filter(survey=survey)
        serializer = SurveyAttachmentSerializer(attachments, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def audit_logs(self, request, pk=None):
        """Get audit log for this survey"""
        survey = self.get_object()
        logs = SurveyAuditLog.objects.filter(survey=survey).order_by('-timestamp')
        serializer = SurveyAuditLogSerializer(logs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Get survey statistics"""
        queryset = self.get_queryset()

        total_surveys = queryset.count()

        # Status distribution
        status_distribution = queryset.values('verification_status').annotate(
            count=Count('id')
        )

        # Surveys by surveyor
        surveyor_stats = queryset.values(
            'surveyor__email', 'surveyor__first_name', 'surveyor__last_name'
        ).annotate(count=Count('id')).order_by('-count')

        # Average occupancy rate
        avg_occupancy = queryset.exclude(
            current_bed_capacity=0
        ).aggregate(
            avg_occupancy=Avg('beds_occupied') * 100.0 / Avg('current_bed_capacity')
        )['avg_occupancy'] or 0

        # Recent surveys (last 30 days)
        from datetime import timedelta
        thirty_days_ago = timezone.now() - timedelta(days=30)
        recent_surveys = queryset.filter(created_at__gte=thirty_days_ago).count()

        return Response({
            'total_surveys': total_surveys,
            'status_distribution': list(status_distribution),
            'top_surveyors': list(surveyor_stats)[:10],
            'average_occupancy_rate': round(avg_occupancy, 2),
            'recent_surveys': recent_surveys
        })


class SurveyAttachmentViewSet(viewsets.ModelViewSet):
    """
    ViewSet for SurveyAttachment
    """
    queryset = SurveyAttachment.objects.select_related('survey', 'uploaded_by')
    serializer_class = SurveyAttachmentSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['survey', 'attachment_type', 'uploaded_by']
    ordering = ['-uploaded_at']

    def perform_create(self, serializer):
        """Set uploaded_by to current user and log activity"""
        instance = serializer.save(uploaded_by=self.request.user)
        filename = instance.file.name if instance.file else 'unknown'
        log_file_upload(self.request, instance, filename)

    def perform_destroy(self, instance):
        """Delete attachment and log activity"""
        log_delete(self.request, instance, f'Deleted attachment: {instance.file.name}')
        instance.delete()


class SurveyAuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for SurveyAuditLog (read-only)
    """
    queryset = SurveyAuditLog.objects.select_related('survey', 'user')
    serializer_class = SurveyAuditLogSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['survey', 'action', 'user', 'previous_status', 'new_status']
    ordering = ['-timestamp']


# =============================================================================
# DYNAMIC QUESTIONNAIRE VIEWSETS
# =============================================================================

class GeographicUnitViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for Geographic Units (read-only)
    Provides hierarchical administrative unit data for cascading dropdowns
    """
    queryset = GeographicUnit.objects.select_related('parent').filter(is_active=True)
    serializer_class = GeographicUnitSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['level', 'parent', 'is_active']
    search_fields = ['name', 'code']
    ordering = ['level', 'name']

    @action(detail=False, methods=['get'])
    def by_level(self, request):
        """Get units by level with optional parent filter"""
        level = request.query_params.get('level')
        parent_id = request.query_params.get('parent')

        queryset = self.get_queryset()

        if level:
            queryset = queryset.filter(level=level)
        if parent_id:
            queryset = queryset.filter(parent_id=parent_id)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def children(self, request, pk=None):
        """Get children of a geographic unit"""
        unit = self.get_object()
        children = unit.children.filter(is_active=True).order_by('name')
        serializer = self.get_serializer(children, many=True)
        return Response(serializer.data)


class SurveyTemplateViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for Survey Templates (read-only for surveyors)
    Returns templates with their sections and questions
    """
    queryset = SurveyTemplate.objects.filter(is_active=True).prefetch_related(
        'sections__questions__choices'
    )
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['template_type', 'is_active', 'target_mtc']
    search_fields = ['name', 'code', 'description']
    ordering = ['template_type', 'name']

    def get_serializer_class(self):
        if self.action == 'list':
            return SurveyTemplateListSerializer
        return SurveyTemplateDetailSerializer

    @action(detail=True, methods=['get'])
    def sections(self, request, pk=None):
        """Get sections for a template"""
        template = self.get_object()
        sections = template.sections.prefetch_related('questions__choices').order_by('order')
        from .serializers import QuestionSectionSerializer
        serializer = QuestionSectionSerializer(sections, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def questions(self, request, pk=None):
        """Get all questions for a template (flat list)"""
        template = self.get_object()
        questions = Question.objects.filter(
            section__template=template
        ).select_related('section').prefetch_related('choices').order_by(
            'section__order', 'order'
        )
        from .serializers import QuestionSerializer
        serializer = QuestionSerializer(questions, many=True)
        return Response(serializer.data)


class QuestionViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing Questions (ADMIN only)
    Supports CRUD operations for survey template questions
    """
    queryset = Question.objects.select_related('section', 'mtc_code').prefetch_related('choices')
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['section', 'section__template', 'answer_type', 'is_required']
    search_fields = ['code', 'question_text', 'keterangan']
    ordering = ['section__order', 'order']

    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return QuestionCreateUpdateSerializer
        return QuestionSerializer

    def get_permissions(self):
        # Only ADMIN can modify questions
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            from apps.accounts.permissions import IsAdmin
            return [IsAdmin()]
        return [IsAuthenticated()]


class QuestionChoiceViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing Question Choices (ADMIN only)
    Supports CRUD operations for question answer choices
    """
    queryset = QuestionChoice.objects.select_related('question', 'mtc_code')
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['question', 'question__section__template']
    search_fields = ['value', 'label', 'keterangan']
    ordering = ['question__section__order', 'question__order', 'order']

    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return QuestionChoiceCreateUpdateSerializer
        return QuestionChoiceSerializer

    def get_permissions(self):
        # Only ADMIN can modify choices
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            from apps.accounts.permissions import IsAdmin
            return [IsAdmin()]
        return [IsAuthenticated()]


class DynamicSurveyResponseViewSet(SurveyorFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for Dynamic Survey Responses with verification workflow
    """
    queryset = DynamicSurveyResponse.objects.select_related(
        'template', 'service', 'surveyor', 'assigned_verifier', 'verified_by'
    ).prefetch_related('answers__question', 'answers__selected_choices')
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]

    filterset_fields = {
        'template': ['exact'],
        'service': ['exact'],
        'surveyor': ['exact'],
        'verification_status': ['exact'],
        'assigned_verifier': ['exact'],
        'survey_date': ['exact', 'gte', 'lte'],
        'created_at': ['gte', 'lte'],
    }

    search_fields = ['service__name', 'surveyor__email', 'surveyor_notes']
    ordering_fields = ['survey_date', 'created_at', 'verification_status']
    ordering = ['-survey_date']

    # RBAC Mixin Configuration
    rbac_surveyor_field = 'surveyor'
    rbac_verifier_field = 'assigned_verifier'
    rbac_status_field = 'verification_status'
    rbac_verified_status = 'VERIFIED'
    rbac_submitted_status = 'SUBMITTED'
    rbac_admin_sees_all = True
    rbac_allow_superuser = True

    def get_serializer_class(self):
        if self.action == 'list':
            return DynamicSurveyResponseListSerializer
        elif self.action in ['create']:
            return DynamicSurveyResponseCreateSerializer
        return DynamicSurveyResponseDetailSerializer

    def perform_create(self, serializer):
        """Create survey response with current user as surveyor"""
        instance = serializer.save()
        log_create(self.request, instance, f'Created dynamic survey response for template: {instance.template.name}')

    @action(detail=True, methods=['post'])
    def save_progress(self, request, pk=None):
        """Save progress on a draft survey"""
        response = self.get_object()

        if response.verification_status != DynamicSurveyResponse.Status.DRAFT:
            return Response(
                {'detail': 'Can only save progress on draft surveys'},
                status=status.HTTP_400_BAD_REQUEST
            )

        if response.surveyor != request.user and request.user.role != 'ADMIN':
            return Response(
                {'detail': 'Only the surveyor can update this response'},
                status=status.HTTP_403_FORBIDDEN
            )

        answers_data = request.data.get('answers', {})
        self._update_answers(response, answers_data)

        return Response(DynamicSurveyResponseDetailSerializer(response).data)

    @action(detail=True, methods=['post'])
    def submit(self, request, pk=None):
        """Submit survey for verification"""
        response = self.get_object()

        if response.verification_status != DynamicSurveyResponse.Status.DRAFT:
            return Response(
                {'detail': 'Only draft surveys can be submitted'},
                status=status.HTTP_400_BAD_REQUEST
            )

        if response.surveyor != request.user and request.user.role != 'ADMIN':
            return Response(
                {'detail': 'Only the surveyor can submit this response'},
                status=status.HTTP_403_FORBIDDEN
            )

        response.verification_status = DynamicSurveyResponse.Status.SUBMITTED
        response.submitted_at = timezone.now()
        response.save()

        log_survey_submit(request, response)

        return Response(DynamicSurveyResponseDetailSerializer(response).data)

    @action(detail=True, methods=['post'])
    def verify(self, request, pk=None):
        """Verify or reject survey"""
        response = self.get_object()

        if response.verification_status != DynamicSurveyResponse.Status.SUBMITTED:
            return Response(
                {'detail': 'Only submitted surveys can be verified'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Strict separation of duties: cannot verify your own submission
        if response.surveyor == request.user:
            return Response(
                {'detail': 'You cannot verify your own survey submission'},
                status=status.HTTP_403_FORBIDDEN
            )

        # Check if user has permission to verify (VERIFIER or ADMIN)
        if request.user.role not in ['VERIFIER', 'ADMIN']:
            return Response(
                {'detail': 'Only verifiers and admins can verify surveys'},
                status=status.HTTP_403_FORBIDDEN
            )

        action_type = request.data.get('action')
        notes = request.data.get('notes', '')

        if action_type == 'verify':
            response.verification_status = DynamicSurveyResponse.Status.VERIFIED
            response.verified_by = request.user
            response.verified_at = timezone.now()
            response.verifier_notes = notes
            log_survey_verify(request, response)
        elif action_type == 'reject':
            response.verification_status = DynamicSurveyResponse.Status.REJECTED
            response.rejection_reason = request.data.get('rejection_reason', '')
            response.verifier_notes = notes
            log_survey_reject(request, response, response.rejection_reason)
        else:
            return Response(
                {'detail': 'Invalid action. Use "verify" or "reject"'},
                status=status.HTTP_400_BAD_REQUEST
            )

        response.save()
        return Response(DynamicSurveyResponseDetailSerializer(response).data)

    def _update_answers(self, response, answers_data):
        """Update answers for a response"""
        template = response.template
        questions = Question.objects.filter(section__template=template)
        question_map = {q.code: q for q in questions}

        for question_code, answer_value in answers_data.items():
            question = question_map.get(question_code)
            if not question:
                continue

            # Get or create the answer
            answer, created = QuestionAnswer.objects.get_or_create(
                response=response,
                question=question
            )

            # Clear existing values
            answer.text_value = ''
            answer.number_value = None
            answer.date_value = None
            answer.time_value = None
            answer.boolean_value = None
            answer.geographic_unit = None
            answer.coverage_level = ''
            answer.table_data = None
            answer.gps_latitude = None
            answer.gps_longitude = None
            answer.selected_choices.clear()

            # Set the appropriate field based on answer type
            if question.answer_type in ['TEXT', 'TEXTAREA', 'PHONE', 'EMAIL', 'URL']:
                answer.text_value = str(answer_value) if answer_value else ''
            elif question.answer_type in ['NUMBER', 'INTEGER']:
                answer.number_value = answer_value
            elif question.answer_type == 'DATE':
                answer.date_value = answer_value
            elif question.answer_type == 'TIME':
                answer.time_value = answer_value
            elif question.answer_type == 'BOOLEAN':
                answer.boolean_value = answer_value
            elif question.answer_type in ['GEO_PROVINSI', 'GEO_KABUPATEN', 'GEO_KECAMATAN']:
                if answer_value:
                    answer.geographic_unit_id = answer_value
            elif question.answer_type == 'GEO_DESA':
                # GEO_DESA is stored as text (user types desa name)
                answer.text_value = str(answer_value) if answer_value else ''
            elif question.answer_type == 'GEO_FULL':
                # GEO_FULL stores location data as JSON in table_data
                if answer_value:
                    answer.table_data = answer_value
            elif question.answer_type == 'COVERAGE_LEVEL':
                answer.coverage_level = answer_value
            elif question.answer_type in ['STAFF_TABLE', 'DIAGNOSIS_TABLE']:
                answer.table_data = answer_value
            elif question.answer_type == 'GPS':
                if isinstance(answer_value, dict):
                    answer.gps_latitude = answer_value.get('latitude')
                    answer.gps_longitude = answer_value.get('longitude')
            elif question.answer_type in ['SINGLE_CHOICE', 'MULTIPLE_CHOICE']:
                answer.save()
                if isinstance(answer_value, list):
                    from .models import QuestionChoice
                    choices = QuestionChoice.objects.filter(question=question, value__in=answer_value)
                    answer.selected_choices.set(choices)
                elif answer_value:
                    from .models import QuestionChoice
                    choice = QuestionChoice.objects.filter(question=question, value=answer_value).first()
                    if choice:
                        answer.selected_choices.add(choice)
                continue  # Already saved above

            answer.save()
