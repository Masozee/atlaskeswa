def main():
    print("Hello from yakkum!")


if __name__ == "__main__":
    main()
